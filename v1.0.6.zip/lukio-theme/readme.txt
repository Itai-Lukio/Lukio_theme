to create a child theme:
1. create new 'Lukio_theme_child' directory.
2. create 'style.css' file with:
    /*
    Theme Name: child theme name
    Theme URI: https://lukio.pro/
    Description: child theme description
    Author: author name
    Author URI: author site url
    // DO NOT CHANGE <--
    Template: Lukio_theme
    // !-->
    Version: 1.0.0
    Tags: tags..
    */
3. copy the 'templates' and 'template-parts' directories to the new child theme.
4. copy 'screenshot.png'.
5 create 'function.php' if needed.