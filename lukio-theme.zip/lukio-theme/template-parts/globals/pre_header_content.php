<?php

/**
 * This is the template that displays things before the header.
 * 
 * Usefull to display an all site message at the top but out of header sticky
 */

// Exit if accessed directly.
defined('ABSPATH') || exit;
