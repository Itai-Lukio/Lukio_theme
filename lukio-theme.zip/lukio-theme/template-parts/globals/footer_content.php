<?php

/**
 * This is the template that displays the footer content.
 */

// Exit if accessed directly.
defined('ABSPATH') || exit;
?>

Lukio empty <?php echo basename(__FILE__); ?>

<?php
lukio_footer_credit(true);
?>